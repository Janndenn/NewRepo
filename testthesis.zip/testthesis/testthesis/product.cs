﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testthesis
{
    public partial class product : Form
    {
        string imder = null;
        SqlDataAdapter adt = new SqlDataAdapter();
        DataSet ds = new DataSet();
        ConnectionString cd = new ConnectionString();
        SqlCommand cmd = new SqlCommand();
        DataTable dt = new DataTable();
        SqlDataReader rdr = null;
        DataTable dtable = new DataTable();
        SqlConnection con = null;
        public void show()
        {
            adt = new SqlDataAdapter("select * from product", cd.conder);
            adt.Fill(ds);
            ds.Tables[0].Clear();
            adt.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.Columns[0].Width = 150;
            dataGridView1.Columns[1].Width = 150;
            dataGridView1.Columns[2].Width = 150;
            dataGridView1.Columns[3].Width = 0;
            dataGridView1.Columns[4].Width = 150;
            dataGridView1.Columns[5].Width = 0;
            dataGridView1.Columns[6].Width = 150;
            dataGridView1.Columns[7].Width = 0;
            dataGridView1.Columns[8].Width = 180;
            dataGridView1.Columns[9].Width = 150;
            dataGridView1.Columns[10].Width = 180;
            dataGridView1.Columns[11].Width = 180;
            dataGridView1.Columns[12].Width = 150;
            dataGridView1.Columns[13].Width = 180;

            dataGridView1.Columns[0].HeaderText = "ລະຫັດສິນຄ້າ";
            dataGridView1.Columns[1].HeaderText = "ຊື້ສິນຄ້າ";
            dataGridView1.Columns[2].HeaderText = "ຄຳອະທິບາຍ";
            dataGridView1.Columns[3].HeaderText = "supid";
            dataGridView1.Columns[4].HeaderText = "ຜູ້ສະໜອງ";
            dataGridView1.Columns[5].HeaderText = "typeid";
            dataGridView1.Columns[6].HeaderText = "ປະເພດສິນຄ້າ";
            dataGridView1.Columns[7].HeaderText = "brandid";
            dataGridView1.Columns[8].HeaderText = "ຍີ່ຫໍ້ສິນຄ້າ";
            dataGridView1.Columns[9].HeaderText = "ຈຳນວນ";
            dataGridView1.Columns[10].HeaderText = "ຫົວໜ່ວຍສິນຄ້າ";
            dataGridView1.Columns[11].HeaderText = "ລາຄານຳເຂົ້າ";
            dataGridView1.Columns[12].HeaderText = "ລາຄາຂາຍ";
            dataGridView1.Columns[13].HeaderText = "ລາຄາລວມ";
        }

        public product()
        {
            InitializeComponent();

        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void txttype_TextChanged(object sender, EventArgs e)
        {

        }

        private void product_Load(object sender, EventArgs e)
        {
            cd.connect();
            show();
        }

        private void cmbtype_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("insert into product values(@proid,@proname,@ddesc,@supid, @supname,@typeid,@typename,@brandid,@brandname,@jamnoun,@unit,@imprice,@saleprice,@totalprice)", cd.conder);
            cmd.Parameters.AddWithValue("@proid", txtid.Text);
            cmd.Parameters.AddWithValue("@proname", txtname.Text);
            cmd.Parameters.AddWithValue("@ddesc", txtdes.Text);
            cmd.Parameters.AddWithValue("@supid", txtsupid.Text);
            cmd.Parameters.AddWithValue("@supname", txtname.Text);
            cmd.Parameters.AddWithValue("@typeid", txttypeid.Text);
            cmd.Parameters.AddWithValue("@typename", txttype.Text);
            cmd.Parameters.AddWithValue("@brandid", txtbrandid.Text);
            cmd.Parameters.AddWithValue("@brandname", txtbrand.Text);
            cmd.Parameters.AddWithValue("@jamnoun", txtqty.Text);
            cmd.Parameters.AddWithValue("@unit", txtunit.Text);
            cmd.Parameters.AddWithValue("@imprice", txtimp.Text);
            cmd.Parameters.AddWithValue("@saleprice", txtsale.Text);
            cmd.Parameters.AddWithValue("@totalprice", txtprice.Text);
            if (cmd.ExecuteNonQuery() == 1)
            {
                show();
            }
            else { MessageBox.Show("can not save"); }
        }

        private void txtsupid_TextChanged(object sender, EventArgs e)
        {
            if (txtsupid.Text != "")
            {
                SqlConnection co = new SqlConnection(@"Data Source=JANNDENN\SQLEXPRESS; initial Catalog = testthesis; integrated security = True");
                co.Open();
                SqlCommand cc = new SqlCommand("select supname from supplier where supid=@supid", co);
                cc.Parameters.AddWithValue("@supid", txtsupid.Text);
                SqlDataReader rdr = cc.ExecuteReader();
                while (rdr.Read())
                {
                    txtsup.Text = rdr.GetValue(0).ToString();


                }
            }
        }

        private void txttypeid_TextChanged(object sender, EventArgs e)
        {
            if (txttypeid.Text != "")
            {
                SqlConnection co = new SqlConnection(@"Data Source=JANNDENN\SQLEXPRESS; initial Catalog = testthesis; integrated security = True");
                co.Open();
                SqlCommand cc = new SqlCommand("select typename from producttype where typeid=@typeid", co);
                cc.Parameters.AddWithValue("@typeid", txttypeid.Text);
                SqlDataReader rdr = cc.ExecuteReader();
                while (rdr.Read())
                {
                    txttype.Text = rdr.GetValue(0).ToString();


                }
            }
        }

        private void txtbrandid_TextChanged(object sender, EventArgs e)
        {
            if (txtbrandid.Text != "")
            {
                SqlConnection co = new SqlConnection(@"Data Source=JANNDENN\SQLEXPRESS; initial Catalog = testthesis; integrated security = True");
                co.Open();
                SqlCommand cc = new SqlCommand("select brandname from brand where brandid=@brandid", co);
                cc.Parameters.AddWithValue("@brandid", txtbrandid.Text);
                SqlDataReader rdr = cc.ExecuteReader();
                while (rdr.Read())
                {
                    txtbrand.Text = rdr.GetValue(0).ToString();


                }
            }
        }
        public void cal()
        {
            if (!string.IsNullOrEmpty(txtqty.Text) && !string.IsNullOrEmpty(txtsale.Text))
            {
                txtprice.Text = (Convert.ToDouble(txtqty.Text) * Convert.ToDouble(txtsale.Text)).ToString();
            }
        }

        private void txtqty_TextChanged(object sender, EventArgs e)
        {
            cal();
        }

        private void txtsale_TextChanged(object sender, EventArgs e)
        {
            cal();
        }

        private void toolStripMenuItem17_Click(object sender, EventArgs e)
        {
            productreport frm = new productreport();
            frm.Show();
        }
        private void button2_Click(object sender, EventArgs e)
        {

        }

    }
    
}

