﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace testthesis
{
    public partial class salerecord : Form
    {
        string imder = null;
        SqlDataAdapter adt = new SqlDataAdapter();
        DataSet ds = new DataSet();
        ConnectionString cd = new ConnectionString();
        SqlCommand cmd = new SqlCommand();
        DataTable dt = new DataTable();
        SqlDataReader rdr = null;
        DataTable dtable = new DataTable();
        SqlConnection con = null;
        public void show()
        {
            adt = new SqlDataAdapter("select * from sale", cd.conder);
            adt.Fill(ds);
            ds.Tables[0].Clear();
            adt.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];
            dataGridView2.Columns[0].Width = 50;
            dataGridView2.Columns[1].Width = 150;
            dataGridView2.Columns[2].Width = 150;
            dataGridView2.Columns[3].Width = 50;
            dataGridView2.Columns[4].Width = 150;
            dataGridView2.Columns[5].Width = 50;
            dataGridView2.Columns[6].Width = 150;
            dataGridView2.Columns[7].Width = 100;
            dataGridView2.Columns[8].Width = 180;
            dataGridView2.Columns[9].Width = 150;
            dataGridView2.Columns[10].Width = 180;
            dataGridView2.Columns[11].Width = 180;
            dataGridView2.Columns[12].Width = 150;
            dataGridView2.Columns[13].Width = 180;
            dataGridView2.Columns[14].Width = 180;

            dataGridView2.Columns[0].HeaderText = "ລະຫັດການຂາຍ";
            dataGridView2.Columns[1].HeaderText = "ວັນຂາຍ";
            dataGridView2.Columns[2].HeaderText = "ລະຫັດພ/ງ";
            dataGridView2.Columns[3].HeaderText = "ລະຫັດລ/ຄ";
            dataGridView2.Columns[4].HeaderText = "ຊື່ລ/ຄ";
            dataGridView2.Columns[5].HeaderText = "ລະຫັດສິນຄ້າ";
            dataGridView2.Columns[6].HeaderText = "ຊື່ສິນຄ້າ";
            dataGridView2.Columns[7].HeaderText = "ລາຄາ";
            dataGridView2.Columns[8].HeaderText = "discount";
            dataGridView2.Columns[9].HeaderText = "ລາຄາdiscount";
            dataGridView2.Columns[10].HeaderText = "ຈຳນວນ";
            dataGridView2.Columns[11].HeaderText = "ລາຄາລວມ";
            dataGridView2.Columns[12].HeaderText = "ລາຄາທັງໝົດ";
            dataGridView2.Columns[13].HeaderText = "ປະເພດການຊ້ຳລະເງິນ";
            dataGridView2.Columns[14].HeaderText = "ສະກຸນເງິນ";

        }
        public salerecord()
        {
            InitializeComponent();
        }

        private void salerecord_Load(object sender, EventArgs e)
        {
            cd.connect();
            show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlDataAdapter adt = new SqlDataAdapter("select * from sale where saledate between '" + txtdate.Value.ToString() + "' and '" + txttodate.Value.ToString() + "'", cd.conder);
            DataTable dt = new DataTable();
            adt.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void cmbCustomerName_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
