﻿namespace final
{


    partial class dataSetNew
    {
        partial class DataTable9DataTable
        {
        }

        partial class DataTable1DataTable
        {
        }
    }
}
