﻿namespace final
{
    partial class frmMainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ຈດການຂມນToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຈດການຂມນປະເພດສນຄາToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຈດການຂມນຍຫສນຄາToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຈດການຂມນຫວໜວຍສນຄາToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຈດການຂມນສນຄາToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຈດການຂມນພະນກງານToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຈດການຂມນໂປຣໂມຊນToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຈດການຂມນລກຄາToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຈດການຂມນອດຕາແລກປຽນToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ລາຍງານToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ລາຍງານຂມນພະນກງານToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ລາຍງານຂມນສນຄາToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ລາຍງານຂມນການຂາຍToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ຂມນໃບບນToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ລາຍງານຂມນນຳເຂາຕາມວນທເວລາToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ລາຍງານຂມນລາຍຮບToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ລາຍງານຂມນລາຍຈາຍToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ລາຍງານຂມນສນຄາມບນຫາToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ລາຍງານຂມນຜສະໜອງToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ລາຍງານຂມນລກຄາToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ອອກລະບບToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.RosyBrown;
            this.menuStrip1.Font = new System.Drawing.Font("Phetsarath OT", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ຈດການຂມນToolStripMenuItem,
            this.ລາຍງານToolStripMenuItem,
            this.ອອກລະບບToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1567, 68);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ຈດການຂມນToolStripMenuItem
            // 
            this.ຈດການຂມນToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ຈດການຂມນປະເພດສນຄາToolStripMenuItem,
            this.ຈດການຂມນຍຫສນຄາToolStripMenuItem,
            this.ຈດການຂມນຫວໜວຍສນຄາToolStripMenuItem,
            this.ຈດການຂມນສນຄາToolStripMenuItem,
            this.ຈດການຂມນພະນກງານToolStripMenuItem,
            this.ຈດການຂມນໂປຣໂມຊນToolStripMenuItem,
            this.ຈດການຂມນລກຄາToolStripMenuItem,
            this.ຈດການຂມນອດຕາແລກປຽນToolStripMenuItem});
            this.ຈດການຂມນToolStripMenuItem.Image = global::final.Properties.Resources.folder_icon;
            this.ຈດການຂມນToolStripMenuItem.Name = "ຈດການຂມນToolStripMenuItem";
            this.ຈດການຂມນToolStripMenuItem.Size = new System.Drawing.Size(231, 64);
            this.ຈດການຂມນToolStripMenuItem.Text = "ຈັດການຂໍ້ມູນພື້ນຖານ";
            this.ຈດການຂມນToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // ຈດການຂມນປະເພດສນຄາToolStripMenuItem
            // 
            this.ຈດການຂມນປະເພດສນຄາToolStripMenuItem.Image = global::final.Properties.Resources.file_data_icon;
            this.ຈດການຂມນປະເພດສນຄາToolStripMenuItem.Name = "ຈດການຂມນປະເພດສນຄາToolStripMenuItem";
            this.ຈດການຂມນປະເພດສນຄາToolStripMenuItem.Size = new System.Drawing.Size(394, 44);
            this.ຈດການຂມນປະເພດສນຄາToolStripMenuItem.Text = "ຈັດການຂໍ້ມູນປະເພດສິນຄ້າ";
            this.ຈດການຂມນປະເພດສນຄາToolStripMenuItem.Click += new System.EventHandler(this.ຈດການຂມນປະເພດສນຄາToolStripMenuItem_Click);
            // 
            // ຈດການຂມນຍຫສນຄາToolStripMenuItem
            // 
            this.ຈດການຂມນຍຫສນຄາToolStripMenuItem.Image = global::final.Properties.Resources.file_data_icon;
            this.ຈດການຂມນຍຫສນຄາToolStripMenuItem.Name = "ຈດການຂມນຍຫສນຄາToolStripMenuItem";
            this.ຈດການຂມນຍຫສນຄາToolStripMenuItem.Size = new System.Drawing.Size(394, 44);
            this.ຈດການຂມນຍຫສນຄາToolStripMenuItem.Text = "ຈັດການຂໍ້ມູນຍີ່ຫໍ້ສິນຄ້າ";
            this.ຈດການຂມນຍຫສນຄາToolStripMenuItem.Click += new System.EventHandler(this.ຈດການຂມນຍຫສນຄາToolStripMenuItem_Click);
            // 
            // ຈດການຂມນຫວໜວຍສນຄາToolStripMenuItem
            // 
            this.ຈດການຂມນຫວໜວຍສນຄາToolStripMenuItem.Image = global::final.Properties.Resources.file_data_icon;
            this.ຈດການຂມນຫວໜວຍສນຄາToolStripMenuItem.Name = "ຈດການຂມນຫວໜວຍສນຄາToolStripMenuItem";
            this.ຈດການຂມນຫວໜວຍສນຄາToolStripMenuItem.Size = new System.Drawing.Size(394, 44);
            this.ຈດການຂມນຫວໜວຍສນຄາToolStripMenuItem.Text = "ຈັດການຂໍ້ມູນຫົວໜ່ວຍສິນຄ້າ";
            this.ຈດການຂມນຫວໜວຍສນຄາToolStripMenuItem.Click += new System.EventHandler(this.ຈດການຂມນຫວໜວຍສນຄາToolStripMenuItem_Click);
            // 
            // ຈດການຂມນສນຄາToolStripMenuItem
            // 
            this.ຈດການຂມນສນຄາToolStripMenuItem.Image = global::final.Properties.Resources.file_data_icon;
            this.ຈດການຂມນສນຄາToolStripMenuItem.Name = "ຈດການຂມນສນຄາToolStripMenuItem";
            this.ຈດການຂມນສນຄາToolStripMenuItem.Size = new System.Drawing.Size(394, 44);
            this.ຈດການຂມນສນຄາToolStripMenuItem.Text = "ຈັດການຂໍ້ມູນສິນຄ້າ";
            this.ຈດການຂມນສນຄາToolStripMenuItem.Click += new System.EventHandler(this.ຈດການຂມນສນຄາToolStripMenuItem_Click);
            // 
            // ຈດການຂມນພະນກງານToolStripMenuItem
            // 
            this.ຈດການຂມນພະນກງານToolStripMenuItem.Image = global::final.Properties.Resources.file_data_icon;
            this.ຈດການຂມນພະນກງານToolStripMenuItem.Name = "ຈດການຂມນພະນກງານToolStripMenuItem";
            this.ຈດການຂມນພະນກງານToolStripMenuItem.Size = new System.Drawing.Size(394, 44);
            this.ຈດການຂມນພະນກງານToolStripMenuItem.Text = "ຈັດການຂໍ້ມູນພະນັກງານ";
            this.ຈດການຂມນພະນກງານToolStripMenuItem.Click += new System.EventHandler(this.ຈດການຂມນພະນກງານToolStripMenuItem_Click);
            // 
            // ຈດການຂມນໂປຣໂມຊນToolStripMenuItem
            // 
            this.ຈດການຂມນໂປຣໂມຊນToolStripMenuItem.Image = global::final.Properties.Resources.file_data_icon;
            this.ຈດການຂມນໂປຣໂມຊນToolStripMenuItem.Name = "ຈດການຂມນໂປຣໂມຊນToolStripMenuItem";
            this.ຈດການຂມນໂປຣໂມຊນToolStripMenuItem.Size = new System.Drawing.Size(394, 44);
            this.ຈດການຂມນໂປຣໂມຊນToolStripMenuItem.Text = "ຈັດການຂໍ້ມູນຜູ້ສະໜອງ";
            this.ຈດການຂມນໂປຣໂມຊນToolStripMenuItem.Click += new System.EventHandler(this.ຈດການຂມນໂປຣໂມຊນToolStripMenuItem_Click);
            // 
            // ຈດການຂມນລກຄາToolStripMenuItem
            // 
            this.ຈດການຂມນລກຄາToolStripMenuItem.Image = global::final.Properties.Resources.file_data_icon;
            this.ຈດການຂມນລກຄາToolStripMenuItem.Name = "ຈດການຂມນລກຄາToolStripMenuItem";
            this.ຈດການຂມນລກຄາToolStripMenuItem.Size = new System.Drawing.Size(394, 44);
            this.ຈດການຂມນລກຄາToolStripMenuItem.Text = "ຈັດການຂໍ້ມູນລູກຄ້າ";
            this.ຈດການຂມນລກຄາToolStripMenuItem.Click += new System.EventHandler(this.ຈດການຂມນລກຄາToolStripMenuItem_Click);
            // 
            // ຈດການຂມນອດຕາແລກປຽນToolStripMenuItem
            // 
            this.ຈດການຂມນອດຕາແລກປຽນToolStripMenuItem.Image = global::final.Properties.Resources.file_data_icon;
            this.ຈດການຂມນອດຕາແລກປຽນToolStripMenuItem.Name = "ຈດການຂມນອດຕາແລກປຽນToolStripMenuItem";
            this.ຈດການຂມນອດຕາແລກປຽນToolStripMenuItem.Size = new System.Drawing.Size(394, 44);
            this.ຈດການຂມນອດຕາແລກປຽນToolStripMenuItem.Text = "ຈັດການຂໍ້ມູນອັດຕາແລກປ່ຽນ";
            this.ຈດການຂມນອດຕາແລກປຽນToolStripMenuItem.Click += new System.EventHandler(this.ຈດການຂມນອດຕາແລກປຽນToolStripMenuItem_Click);
            // 
            // ລາຍງານToolStripMenuItem
            // 
            this.ລາຍງານToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ລາຍງານຂມນພະນກງານToolStripMenuItem,
            this.ລາຍງານຂມນສນຄາToolStripMenuItem,
            this.ລາຍງານຂມນການຂາຍToolStripMenuItem,
            this.ຂມນໃບບນToolStripMenuItem,
            this.ລາຍງານຂມນນຳເຂາຕາມວນທເວລາToolStripMenuItem,
            this.ລາຍງານຂມນລາຍຮບToolStripMenuItem,
            this.ລາຍງານຂມນລາຍຈາຍToolStripMenuItem,
            this.ລາຍງານຂມນສນຄາມບນຫາToolStripMenuItem,
            this.ລາຍງານຂມນຜສະໜອງToolStripMenuItem,
            this.ລາຍງານຂມນລກຄາToolStripMenuItem});
            this.ລາຍງານToolStripMenuItem.Image = global::final.Properties.Resources.file_icon;
            this.ລາຍງານToolStripMenuItem.Name = "ລາຍງານToolStripMenuItem";
            this.ລາຍງານToolStripMenuItem.Size = new System.Drawing.Size(110, 64);
            this.ລາຍງານToolStripMenuItem.Text = "ລາຍງານ";
            this.ລາຍງານToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // ລາຍງານຂມນພະນກງານToolStripMenuItem
            // 
            this.ລາຍງານຂມນພະນກງານToolStripMenuItem.Image = global::final.Properties.Resources.PDF_file_icon_svg;
            this.ລາຍງານຂມນພະນກງານToolStripMenuItem.Name = "ລາຍງານຂມນພະນກງານToolStripMenuItem";
            this.ລາຍງານຂມນພະນກງານToolStripMenuItem.Size = new System.Drawing.Size(478, 44);
            this.ລາຍງານຂມນພະນກງານToolStripMenuItem.Text = "ລາຍງານຂໍ້ມູນການຂາຍພະນັກງານ";
            this.ລາຍງານຂມນພະນກງານToolStripMenuItem.Click += new System.EventHandler(this.ລາຍງານຂມນພະນກງານToolStripMenuItem_Click);
            // 
            // ລາຍງານຂມນສນຄາToolStripMenuItem
            // 
            this.ລາຍງານຂມນສນຄາToolStripMenuItem.Image = global::final.Properties.Resources.PDF_file_icon_svg;
            this.ລາຍງານຂມນສນຄາToolStripMenuItem.Name = "ລາຍງານຂມນສນຄາToolStripMenuItem";
            this.ລາຍງານຂມນສນຄາToolStripMenuItem.Size = new System.Drawing.Size(478, 44);
            this.ລາຍງານຂມນສນຄາToolStripMenuItem.Text = "ລາຍງານຂໍ້ມູນສິນຄ້າ";
            this.ລາຍງານຂມນສນຄາToolStripMenuItem.Click += new System.EventHandler(this.ລາຍງານຂມນສນຄາToolStripMenuItem_Click);
            // 
            // ລາຍງານຂມນການຂາຍToolStripMenuItem
            // 
            this.ລາຍງານຂມນການຂາຍToolStripMenuItem.Image = global::final.Properties.Resources.PDF_file_icon_svg;
            this.ລາຍງານຂມນການຂາຍToolStripMenuItem.Name = "ລາຍງານຂມນການຂາຍToolStripMenuItem";
            this.ລາຍງານຂມນການຂາຍToolStripMenuItem.Size = new System.Drawing.Size(478, 44);
            this.ລາຍງານຂມນການຂາຍToolStripMenuItem.Text = "ລາຍງານຂໍ້ມູນການຂາຍຕາມວັນທີເວລາ";
            this.ລາຍງານຂມນການຂາຍToolStripMenuItem.Click += new System.EventHandler(this.ລາຍງານຂມນການຂາຍToolStripMenuItem_Click);
            // 
            // ຂມນໃບບນToolStripMenuItem
            // 
            this.ຂມນໃບບນToolStripMenuItem.Image = global::final.Properties.Resources.PDF_file_icon_svg;
            this.ຂມນໃບບນToolStripMenuItem.Name = "ຂມນໃບບນToolStripMenuItem";
            this.ຂມນໃບບນToolStripMenuItem.Size = new System.Drawing.Size(478, 44);
            this.ຂມນໃບບນToolStripMenuItem.Text = "ລາຍງານຂໍ້ມູນສັ່ງຊື້ຕາມວັນທີເວລາ";
            this.ຂມນໃບບນToolStripMenuItem.Click += new System.EventHandler(this.ຂມນໃບບນToolStripMenuItem_Click);
            // 
            // ລາຍງານຂມນນຳເຂາຕາມວນທເວລາToolStripMenuItem
            // 
            this.ລາຍງານຂມນນຳເຂາຕາມວນທເວລາToolStripMenuItem.Image = global::final.Properties.Resources.PDF_file_icon_svg;
            this.ລາຍງານຂມນນຳເຂາຕາມວນທເວລາToolStripMenuItem.Name = "ລາຍງານຂມນນຳເຂາຕາມວນທເວລາToolStripMenuItem";
            this.ລາຍງານຂມນນຳເຂາຕາມວນທເວລາToolStripMenuItem.Size = new System.Drawing.Size(478, 44);
            this.ລາຍງານຂມນນຳເຂາຕາມວນທເວລາToolStripMenuItem.Text = "ລາຍງານຂໍ້ມູນນຳເຂົ້າຕາມວັນທີເວລາ";
            this.ລາຍງານຂມນນຳເຂາຕາມວນທເວລາToolStripMenuItem.Click += new System.EventHandler(this.ລາຍງານຂມນນຳເຂາຕາມວນທເວລາToolStripMenuItem_Click);
            // 
            // ລາຍງານຂມນລາຍຮບToolStripMenuItem
            // 
            this.ລາຍງານຂມນລາຍຮບToolStripMenuItem.Image = global::final.Properties.Resources.PDF_file_icon_svg;
            this.ລາຍງານຂມນລາຍຮບToolStripMenuItem.Name = "ລາຍງານຂມນລາຍຮບToolStripMenuItem";
            this.ລາຍງານຂມນລາຍຮບToolStripMenuItem.Size = new System.Drawing.Size(478, 44);
            this.ລາຍງານຂມນລາຍຮບToolStripMenuItem.Text = "ລາຍງານຂໍ້ມູນລາຍຮັບ";
            this.ລາຍງານຂມນລາຍຮບToolStripMenuItem.Click += new System.EventHandler(this.ລາຍງານຂມນລາຍຮບToolStripMenuItem_Click);
            // 
            // ລາຍງານຂມນລາຍຈາຍToolStripMenuItem
            // 
            this.ລາຍງານຂມນລາຍຈາຍToolStripMenuItem.Image = global::final.Properties.Resources.PDF_file_icon_svg;
            this.ລາຍງານຂມນລາຍຈາຍToolStripMenuItem.Name = "ລາຍງານຂມນລາຍຈາຍToolStripMenuItem";
            this.ລາຍງານຂມນລາຍຈາຍToolStripMenuItem.Size = new System.Drawing.Size(478, 44);
            this.ລາຍງານຂມນລາຍຈາຍToolStripMenuItem.Text = "ລາຍງານຂໍ້ມູນລາຍຈ່າຍ";
            this.ລາຍງານຂມນລາຍຈາຍToolStripMenuItem.Click += new System.EventHandler(this.ລາຍງານຂມນລາຍຈາຍToolStripMenuItem_Click);
            // 
            // ລາຍງານຂມນສນຄາມບນຫາToolStripMenuItem
            // 
            this.ລາຍງານຂມນສນຄາມບນຫາToolStripMenuItem.Image = global::final.Properties.Resources.PDF_file_icon_svg;
            this.ລາຍງານຂມນສນຄາມບນຫາToolStripMenuItem.Name = "ລາຍງານຂມນສນຄາມບນຫາToolStripMenuItem";
            this.ລາຍງານຂມນສນຄາມບນຫາToolStripMenuItem.Size = new System.Drawing.Size(478, 44);
            this.ລາຍງານຂມນສນຄາມບນຫາToolStripMenuItem.Text = "ລາຍງານຂໍ້ມູນສິນຄ້າມີບັນຫາ";
            this.ລາຍງານຂມນສນຄາມບນຫາToolStripMenuItem.Click += new System.EventHandler(this.ລາຍງານຂມນສນຄາມບນຫາToolStripMenuItem_Click);
            // 
            // ລາຍງານຂມນຜສະໜອງToolStripMenuItem
            // 
            this.ລາຍງານຂມນຜສະໜອງToolStripMenuItem.Image = global::final.Properties.Resources.PDF_file_icon_svg;
            this.ລາຍງານຂມນຜສະໜອງToolStripMenuItem.Name = "ລາຍງານຂມນຜສະໜອງToolStripMenuItem";
            this.ລາຍງານຂມນຜສະໜອງToolStripMenuItem.Size = new System.Drawing.Size(478, 44);
            this.ລາຍງານຂມນຜສະໜອງToolStripMenuItem.Text = "ລາຍງານຂໍ້ມູນຜູ້ສະໜອງ";
            this.ລາຍງານຂມນຜສະໜອງToolStripMenuItem.Click += new System.EventHandler(this.ລາຍງານຂມນຜສະໜອງToolStripMenuItem_Click);
            // 
            // ລາຍງານຂມນລກຄາToolStripMenuItem
            // 
            this.ລາຍງານຂມນລກຄາToolStripMenuItem.Image = global::final.Properties.Resources.PDF_file_icon_svg;
            this.ລາຍງານຂມນລກຄາToolStripMenuItem.Name = "ລາຍງານຂມນລກຄາToolStripMenuItem";
            this.ລາຍງານຂມນລກຄາToolStripMenuItem.Size = new System.Drawing.Size(478, 44);
            this.ລາຍງານຂມນລກຄາToolStripMenuItem.Text = "ລາຍງານຂໍ້ມູນລູກຄ້າ";
            this.ລາຍງານຂມນລກຄາToolStripMenuItem.Click += new System.EventHandler(this.ລາຍງານຂມນລກຄາToolStripMenuItem_Click);
            // 
            // ອອກລະບບToolStripMenuItem
            // 
            this.ອອກລະບບToolStripMenuItem.Image = global::final.Properties.Resources.logout_icon;
            this.ອອກລະບບToolStripMenuItem.Name = "ອອກລະບບToolStripMenuItem";
            this.ອອກລະບບToolStripMenuItem.Size = new System.Drawing.Size(136, 64);
            this.ອອກລະບບToolStripMenuItem.Text = "ອອກລະບົບ";
            this.ອອກລະບບToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.ອອກລະບບToolStripMenuItem.Click += new System.EventHandler(this.ອອກລະບບToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::final.Properties.Resources.logo3;
            this.pictureBox1.Location = new System.Drawing.Point(53, 111);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(521, 698);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Phetsarath OT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Image = global::final.Properties.Resources.problem1;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button3.Location = new System.Drawing.Point(1107, 472);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(424, 337);
            this.button3.TabIndex = 4;
            this.button3.Text = "ໜ້າປ່ຽນສິນຄ້າ";
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Phetsarath OT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Image = global::final.Properties.Resources.import1;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button4.Location = new System.Drawing.Point(617, 472);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(424, 337);
            this.button4.TabIndex = 3;
            this.button4.Text = "ໜ້ານຳເຂົ້າສິນຄ້າ";
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Phetsarath OT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Image = global::final.Properties.Resources.bill_buy1;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button2.Location = new System.Drawing.Point(1107, 111);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(424, 337);
            this.button2.TabIndex = 2;
            this.button2.Text = "ໜ້າສັ່ງຊື້ສິນຄ້າ";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Phetsarath OT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Image = global::final.Properties.Resources.pos_terminal;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.Location = new System.Drawing.Point(617, 111);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(424, 337);
            this.button1.TabIndex = 1;
            this.button1.Text = "ໜ້າຂາຍສິນຄ້າ";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmMainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(1567, 902);
            this.ControlBox = false;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Phetsarath OT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmMainMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmMainMenu";
            this.Load += new System.EventHandler(this.frmMainMenu_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ຈດການຂມນToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຈດການຂມນພະນກງານToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຈດການຂມນສນຄາToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຈດການຂມນໂປຣໂມຊນToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ລາຍງານToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ລາຍງານຂມນພະນກງານToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ລາຍງານຂມນສນຄາToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ລາຍງານຂມນການຂາຍToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຂມນໃບບນToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ອອກລະບບToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຈດການຂມນປະເພດສນຄາToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຈດການຂມນຍຫສນຄາToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຈດການຂມນຫວໜວຍສນຄາToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຈດການຂມນລກຄາToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ຈດການຂມນອດຕາແລກປຽນToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem ລາຍງານຂມນນຳເຂາຕາມວນທເວລາToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ລາຍງານຂມນລາຍຮບToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ລາຍງານຂມນລາຍຈາຍToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ລາຍງານຂມນສນຄາມບນຫາToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ລາຍງານຂມນຜສະໜອງToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ລາຍງານຂມນລກຄາToolStripMenuItem;
    }
}