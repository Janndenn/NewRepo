﻿namespace RJVLS
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.btnstudent = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnyear = new System.Windows.Forms.Button();
            this.btnmajor = new System.Windows.Forms.Button();
            this.btnclass = new System.Windows.Forms.Button();
            this.btnregister = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnstudent
            // 
            this.btnstudent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(40)))));
            this.btnstudent.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnstudent.ForeColor = System.Drawing.Color.White;
            this.btnstudent.Image = ((System.Drawing.Image)(resources.GetObject("btnstudent.Image")));
            this.btnstudent.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnstudent.Location = new System.Drawing.Point(434, 326);
            this.btnstudent.Name = "btnstudent";
            this.btnstudent.Size = new System.Drawing.Size(296, 127);
            this.btnstudent.TabIndex = 9;
            this.btnstudent.Text = "Student";
            this.btnstudent.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnstudent.UseVisualStyleBackColor = false;
            this.btnstudent.Click += new System.EventHandler(this.btnstudent_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(806, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(392, 37);
            this.label2.TabIndex = 1;
            this.label2.Text = "faculty of Natural Sciences";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(39, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(158, 168);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(715, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(591, 53);
            this.label1.TabIndex = 0;
            this.label1.Text = "National University Of Laos";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(879, 794);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(296, 127);
            this.button1.TabIndex = 13;
            this.button1.Text = "Close";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnyear
            // 
            this.btnyear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(40)))));
            this.btnyear.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnyear.ForeColor = System.Drawing.Color.White;
            this.btnyear.Image = ((System.Drawing.Image)(resources.GetObject("btnyear.Image")));
            this.btnyear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnyear.Location = new System.Drawing.Point(1631, 475);
            this.btnyear.Name = "btnyear";
            this.btnyear.Size = new System.Drawing.Size(296, 127);
            this.btnyear.TabIndex = 12;
            this.btnyear.Text = "Year";
            this.btnyear.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnyear.UseVisualStyleBackColor = false;
            this.btnyear.Click += new System.EventHandler(this.btnyear_Click);
            // 
            // btnmajor
            // 
            this.btnmajor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(40)))));
            this.btnmajor.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmajor.ForeColor = System.Drawing.Color.White;
            this.btnmajor.Image = ((System.Drawing.Image)(resources.GetObject("btnmajor.Image")));
            this.btnmajor.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnmajor.Location = new System.Drawing.Point(1305, 326);
            this.btnmajor.Name = "btnmajor";
            this.btnmajor.Size = new System.Drawing.Size(296, 127);
            this.btnmajor.TabIndex = 11;
            this.btnmajor.Text = "Major";
            this.btnmajor.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnmajor.UseVisualStyleBackColor = false;
            this.btnmajor.Click += new System.EventHandler(this.btnmajor_Click);
            // 
            // btnclass
            // 
            this.btnclass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(40)))));
            this.btnclass.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclass.ForeColor = System.Drawing.Color.White;
            this.btnclass.Image = ((System.Drawing.Image)(resources.GetObject("btnclass.Image")));
            this.btnclass.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnclass.Location = new System.Drawing.Point(879, 475);
            this.btnclass.Name = "btnclass";
            this.btnclass.Size = new System.Drawing.Size(296, 127);
            this.btnclass.TabIndex = 10;
            this.btnclass.Text = "Class";
            this.btnclass.UseVisualStyleBackColor = false;
            this.btnclass.Click += new System.EventHandler(this.btnclass_Click);
            // 
            // btnregister
            // 
            this.btnregister.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(40)))));
            this.btnregister.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregister.ForeColor = System.Drawing.Color.White;
            this.btnregister.Image = ((System.Drawing.Image)(resources.GetObject("btnregister.Image")));
            this.btnregister.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnregister.Location = new System.Drawing.Point(93, 475);
            this.btnregister.Name = "btnregister";
            this.btnregister.Size = new System.Drawing.Size(296, 127);
            this.btnregister.TabIndex = 8;
            this.btnregister.Text = "Register";
            this.btnregister.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnregister.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnregister.UseVisualStyleBackColor = false;
            this.btnregister.Click += new System.EventHandler(this.btnregister_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1902, 171);
            this.panel1.TabIndex = 7;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.btnstudent);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnyear);
            this.Controls.Add(this.btnmajor);
            this.Controls.Add(this.btnclass);
            this.Controls.Add(this.btnregister);
            this.Controls.Add(this.panel1);
            this.Name = "Home";
            this.Text = "Home";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnstudent;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnyear;
        private System.Windows.Forms.Button btnmajor;
        private System.Windows.Forms.Button btnclass;
        private System.Windows.Forms.Button btnregister;
        private System.Windows.Forms.Panel panel1;
    }
}

